import pkg_resources


__version__ = pkg_resources.require("cloudteamisgreat")[0].version